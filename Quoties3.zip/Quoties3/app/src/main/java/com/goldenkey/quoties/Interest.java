package com.goldenkey.quoties;

/**
 * Created by wisam on 3/24/2018.
 */

public class Interest {
    String name;

    public Interest(String name) {
        this.name = name;
    }

    public Interest() {}
}
